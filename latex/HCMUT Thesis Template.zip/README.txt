Repository: https://github.com/hoang-himself/hcmut-thesis
Issues: https://github.com/hoang-himself/hcmut-thesis/issues
Commit: 27987562c97f8a2036591dd781f5bb982ec40221 docs: prevent line breaks after abbreviations
